





print(checkscanning())